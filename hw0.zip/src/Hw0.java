import operations.Expression;
import parser.Lexer;
import parser.Parser;
import parser.TokenStream;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Hw0 {
    public static void main(String[] args) throws IOException {
        Path pathToInputFile = Paths.get("input.txt");
        Path pathToOutputFIle = Paths.get("output.txt");
        BufferedReader reader = Files.newBufferedReader(pathToInputFile);
        BufferedWriter writer = Files.newBufferedWriter(pathToOutputFIle);

        String line = reader.readLine();

        Lexer lex = new Lexer();
        TokenStream str = lex.lexer(line);
        Parser parser = new Parser();
        Expression root = parser.parce(str);
        writer.write(root.toTree());
        reader.close();
        writer.close();

    }
}
