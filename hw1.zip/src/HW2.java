import axioms.AxiomChecker;
import operations.Expression;
import operations.Implication;
import parser.Lexer;
import parser.Parser;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashSet;
import java.util.Set;

public class HW2 {
    private static Set<Expression> hypotises = new HashSet<>();
    public static Expression alpha;

    private static String myTrim(String s) {
        StringBuilder res = new StringBuilder();
        for (int i = 0; i < s.length(); ++i) {
            if (!Character.isWhitespace(s.charAt(i))) {
                res.append(s.charAt(i));
            }
        }
        return res.toString();
    }

    public static void main(String[] args) throws IOException {
        Path pathToInputFile = Paths.get("input.txt");
        BufferedReader reader = Files.newBufferedReader(pathToInputFile);
        String firstLine = reader.readLine().replace("|-", ",");
        String[] hypot = firstLine.split(",");
        int indHyp = 1;
        Parser parser = new Parser();
        Lexer lexer = new Lexer();
        for (int i = 0; i < hypot.length - 2; ++i) {
            if (myTrim(hypot[i]).isEmpty()) {
                continue;
            }
            Expression exp = parser.parce(lexer.lexer(hypot[i]));
            hypotises.add(exp);
        }
        alpha = parser.parce(lexer.lexer(hypot[hypot.length - 2]));
        Expression H = parser.parce(lexer.lexer(hypot[hypot.length - 1]));
        H = new Implication(alpha, H);
        try (PrintWriter out = new PrintWriter(new File("output.txt"))) {
            for (int i = 0; i < hypot.length - 2; ++i) {
                if (i != 0) {
                    out.print(",");
                }
                out.print(myTrim(hypot[i]));
            }
            out.print("|-");
            out.println(H.toString());


            String line;
            while ((line = reader.readLine()) != null) {
                line = myTrim(line);
                if (line.isEmpty()) {
                    continue;
                }
                Expression exp = parser.parce(lexer.lexer(line));
                if (hypotises.contains(exp) || AxiomChecker.checkAll(exp) != 0) {

                }
            }
        }
    }
}
